# AMOC-PROJECT
mock website for the competition
This website will be similar to that of tutorial oriented websites 
